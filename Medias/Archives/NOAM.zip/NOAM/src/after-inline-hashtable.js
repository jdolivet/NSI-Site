  // import structure.HashTable into noam.util
  noam.util.HashTable = structure.HashTable;
  delete structure; // don't need structure any more
