  noam.util.HashTable = require('structure.js').HashTable;
