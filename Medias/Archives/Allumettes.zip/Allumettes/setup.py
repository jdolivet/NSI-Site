from cx_Freeze import setup, Executable
 
#############################################################################
# preparation des options
 
# options d'inclusion/exclusion des modules
includes = []  # nommer les modules non trouves par cx_freeze
packages = ['csv', 'tkinter']  # nommer les packages utilises
 
# copier les fichiers non-Python et/ou repertoires et leur contenu:
includefiles = ['donnees.csv', '1confirmation.csv', '1consigne.csv', '1tableau.csv', '2confirmation.csv', '2consigne.csv', '2tableau.csv', '3confirmation.csv', '3consigne.csv', '3tableau.csv', '4confirmation.csv', '4consigne.csv', '4tableau.csv']
  
# construction du dictionnaire des options
options = {"includes": includes,
           "packages": packages,
           "include_files": includefiles,
           }
  

#############################################################################
# preparation des cibles

cible = Executable(
    script="ProgrammeMain.py",
    )
 
 
#############################################################################
# creation du setup
setup(
    name="Allumettes",
    version="1.00",
    description="Projet ISN 2016",
    author="Samuel Bouilloud - Pierre Corbay",
    options={"build_exe": options},
    executables=[cible]
    )
